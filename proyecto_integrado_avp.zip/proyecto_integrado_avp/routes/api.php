<?php
    use App\Http\Controllers\ProductsController;
    use App\Http\Controllers\AuthController;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Route;

    /*
    |----------------------------------------------------------------
    ----------
    | API Routes
    |----------------------------------------------------------------
    ----------
    |
    | Here is where you can register API routes for your application.
    These
    | routes are loaded by the RouteServiceProvider within a group
    which
    | is assigned the "api" middleware group. Enjoy building your
    API!
    |
    */

    //------------------------- USER -------------------------
    // Funciona
    Route::post('register', [AuthController::class, 'register']); 
    // Funciona
    Route::post('login', [AuthController::class, 'authenticate']); 

    // Funciona
    // Route::get('cargar_datos', [ProductsController::class, 'cargar_datos']); 

    Route::group(['middleware' => ['jwt.verify']], function() {
        //Todo lo que este dentro de este grupo requiere verificación de usuario.
		
		//------------------------- HEADQUARTER -------------------------
		// Devuelve todas las sedes de una empresa
		Route::get('headquarters', [ProductsController::class, 'index_headquarters']);

		//------------------------- OFFERS -------------------------
		Route::get('offers', [ProductsController::class, 'index_offers']);

		//------------------------- COMPANY -------------------------
		// Funciona listado de empresas
		Route::get('companies', [ProductsController::class, 'index_companies']);
		// Función para devolver los detalles de una empresa
		
		// Funciona devuelve los datos de una empresa
		Route::get('companies/{id}', [ProductsController::class, 'show_company']);

        //------------------------- USER -------------------------
        // Funciona
        Route::post('logout', [AuthController::class, 'logout']);
        // Funciona
        Route::post('get-user', [AuthController::class, 'getUser']);
		// Nos devuelve un listado con todos los usuarios:
		Route::get('index_user', [AuthController::class, 'index_users']);
        // Para actualizar un usuario

        //------------------------- COMPANY -------------------------
        // Crea la empresa
        Route::post('companies', [ProductsController::class, 'store_company']);
        // Funciona
        Route::put('companies/{id}', [ProductsController::class, 'update_company']);
        // Funciona
        Route::delete('companies/{id}', [ProductsController::class, 'destroy_company']);

        //------------------------- HEADQUARTER -------------------------
        // Crea la sede
        Route::post('headquarters', [ProductsController::class, 'store_headquarter']);
        // Actualiza una sede
        Route::put('headquarters', [ProductsController::class, 'update_headquarter']);
        // Elimina una sede
        Route::delete('headquarters/{id}', [ProductsController::class, 'destroy_headquarter']);

        //------------------------- OFFERS -------------------------
        // Crea una oferta
        Route::post('offers', [ProductsController::class, 'store_offer']);
        // Actualiza una oferta
        Route::put('offers', [ProductsController::class, 'update_offer']);
        // Elimina una oferta
        Route::delete('offers/{id}', [ProductsController::class, 'destroy_offer']);

    });

