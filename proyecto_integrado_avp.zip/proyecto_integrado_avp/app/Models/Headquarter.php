<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Headquarter extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'company_id'
    ];

    // Una sede solo puede estar relacionada con una empresa
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    // Una sede puede tener varias ofertas
    public function offers()
    {
        return $this->hasMany(Offer::class);
    }
}
