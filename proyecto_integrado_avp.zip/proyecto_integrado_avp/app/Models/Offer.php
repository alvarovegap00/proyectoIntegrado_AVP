<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Offer extends Model
{
    use HasFactory;

    protected $fillable = [
        'is_daw',
        'status',
        'headquarter_id',
        'user_id'
    ];

    // Una oferta solo puede estar relacionada con una sede
    public function headquarter()
    {
        return $this->belongsTo(Headquarter::class);
    }

    // Una oferta solo puede esstar relacionada con un usuario
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
