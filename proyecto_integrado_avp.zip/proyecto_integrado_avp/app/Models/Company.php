<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable; // Para que pueda mandar correos
use Illuminate\Contracts\Auth\MustVerifyEmail; // Para verificar el email

class Company extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'phone',
        'email'
    ];

    // timestamp para email 
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    // Una empresa puede tener varias sedes
    public function headquarters()
    {
        return $this->hasMany(Headquarter::class);
    }
}
