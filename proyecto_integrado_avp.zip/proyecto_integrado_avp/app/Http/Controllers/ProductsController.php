<?php

    namespace App\Http\Controllers;
    use App\Http\Controllers\Controller;
    use App\Models\Company;
    use App\Models\Headquarter;
    use App\Models\Offer;
    use App\Models\User;
    use Illuminate\Http\Request;
    use JWTAuth;
    use Symfony\Component\HttpFoundation\Response;
    use Illuminate\Support\Facades\Validator;
    use Illuminate\Support\Facades\DB; // Para hacer querys

    class ProductsController extends Controller
    {
        protected $user;

        public function __construct(Request $request)
        {
        $token = $request->header('Authorization');

        if($token != '')
            //En caso de que requiera autentificación la ruta obtenemos el usuario y lo almacenamos en una variable, nosotros no lo utilizaremos.
            $this->user = JWTAuth::parseToken()->authenticate();
        }

        /**
        * Display a listing of the resource.
        *
        * @return \Illuminate\Http\Response
        */

        

        // ---------------------------------- COMPANIES ----------------------------------

        // Función para listar las empresas FUNCIONA
        public function index_companies()
        {
            $companies = Company::all();
            return response()->json($companies, Response::HTTP_OK);
        }

        // Función para crear una empresa FUNCIONA
        public function store_company(Request $request) /*quito el student_id que recibe como parametro para que lo reciba por el request*/
        {
            // Cogemos los datos que nos interesa
            $data = $request->only(
                'company_name',
                'company_phone',
                'company_email'
            );

            // Hacemos las validaciones
            $validator = Validator::make($data, [
                'company_name' => 'required|max:50|string',
                'company_phone' => 'required|numeric|unique:companies,phone',
                'company_email' => 'required|email|unique:companies,email'
            ]);

            // Si las validaciones fallan devolvemos el error
            if ($validator->fails()) {
                return response()->json(['error' => $validator->messages()], Response::HTTP_BAD_REQUEST);
            }

            // Creamos la empresa
            $company = Company::create([
                'name' => $request->company_name,
                'phone' => $request->company_phone,
                'email' => $request->company_email
            ]);

            // Devolvemos el JSON
            return response()->json([
                'message' => 'Empresa creada',
                'company' => $company
            ], Response::HTTP_OK);
        }

        // Función para mostrar una empresa en específico FUNCIONA
        public function show_company($id)
        {
            // Buscamos la empresa en concreto 
            $company = Company::findOrFail($id);

            // Devolvemos los datos de la empresa en formato JSON
            return response()->json(['company' => $company], Response::HTTP_OK);
        }

        // Función para actualiazr una empresa FUNCIONA
        public function update_company(Request $request, $company_id)
        {
            // Cogemos los datos que nos interesa
            $data = $request->only(
                'company_name',
                'company_phone',
                'company_email'
            );
        
            // Hacemos las validaciones
            $validator = Validator::make($data, [
                'company_name' => 'required|max:50|string',
                'company_phone' => 'required|numeric|unique:companies,phone,' . $company_id,
                'company_email' => 'required|email|unique:companies,email,' . $company_id
            ]);
        
            // Si la validación falla mostramos el mensaje de error
            if ($validator->fails()) {
                return response()->json(['error' => $validator->messages()], Response::HTTP_BAD_REQUEST);
            }
        
            // Actualizamos los datos de la empresa
            $company = Company::findOrFail($company_id);
            $company->name = $request->company_name;
            $company->phone = $request->company_phone;
            $company->email = $request->company_email;
            $company->save();

            // Actualizamos la empresa
            return response()->json([
                'message' => 'Empresa actualizada',
                'company' => $company,
            ], Response::HTTP_OK);
        }

        // Funcion para eliminar una empresa FUNCIONA
        public function destroy_company ($id){
            //Buscamos la empresa
            $company = Company::findOrfail($id);

            //Eliminamos la empresa
            $company->delete();

            //Devolvemos la respuesta
            return response()->json([
            'message' => 'Empresa eliminada correctamente'
            ], Response::HTTP_OK);
        }


        // ---------------------------------- HEADQUARTERS ----------------------------------

        // Mostramos las sedes de esa empresa FUNCIONA
        public function index_headquarters()
        {
            $company_details = DB::table('headquarters')
                ->join('companies', 'companies.id', '=', "headquarters.company_id")
                ->select('headquarters.id as id', 'headquarters.name as headquarter_name', 'companies.name as company_name', 'companies.id as company_id')
                ->get();

            return response()->json($company_details, Response::HTTP_OK);
        }

        // Función para crear una sede FUNCIONA
        public function store_headquarter(Request $request)
        {
            // Cogemos los datos que nos interesa
            $data = $request->only(
                'headquarter_name',
                'company_id'
            );

            // Hacemos las validaciones
            $validator = Validator::make($data, [
                'headquarter_name' => 'required|max:100|string',
                'company_id' =>'required|numeric'
            ]);

            // Si las validaciones fallan devolvemos el error
            if ($validator->fails()) {
                return response()->json(['error' => $validator->messages()], Response::HTTP_BAD_REQUEST);
            }

            // Creamos la sedes
            $headquarter = Headquarter::create([
                'name' => $request->headquarter_name,
                'company_id' => $request->company_id
            ]);

            // Devolvemos el JSON
            return response()->json([
                'message' => 'Sede creada',
                'headquarter' => $headquarter,
            ], Response::HTTP_OK);
        }

        // Funcion para actualizar una sede FUNCIONA
        public function update_headquarter(Request $request)
        {
            // Cogemos los datos que nos interesa
            $data = $request->only(
                'company_id',
                'headquarter_id',
                'headquarter_name',
                'company_id'
            );
        
            // Hacemos las validaciones
            $validator = Validator::make($data, [
                'headquarter_name' => 'required|max:100|string',
                'company_id' => 'required|numeric'
            ]);
        
            // Si la validación falla mostramos el mensaje de error
            if ($validator->fails()) {
                return response()->json(['error' => $validator->messages()], Response::HTTP_BAD_REQUEST);
            }
        
            // Actualizamos los datos de la empresa
            $headquarter = Headquarter::findOrFail($request->headquarter_id);
            $headquarter->name = $request->headquarter_name;
            $headquarter->company_id = $request->company_id;
            $headquarter->save();

            // Actualizamos la empresa
            return response()->json([
                'message' => 'Sede actualizada',
                'sede' => $headquarter,
            ], Response::HTTP_OK);
        }

        // Funcion para eliminar una sede
        public function destroy_headquarter ($id){
            //Buscamos la empresa
            $headquarter = Headquarter::findOrfail($id);

            //Eliminamos la empresa
            $headquarter->delete();

            //Devolvemos la respuesta
            return response()->json([
            'message' => 'Sede eliminada correctamente'
            ], Response::HTTP_OK);
        }

        // ---------------------------------- OFFERS ----------------------------------

        // Función que devuelve las ofertas que tiene una empresa FUNCION
        public function index_offers()
        {
            $offers = DB::table('offers')
                ->join('headquarters', 'headquarters.id', '=', 'offers.headquarter_id') // Sacamos todas las sede relacionada con esa oferta
                ->join('users', 'users.id', '=', 'offers.user_id') // Sacamos el usuario de esa oferta
                ->join('companies', 'companies.id', '=', 'headquarters.company_id') // Sacamos la empresa relacionada con la sede
                ->select('offers.id as offer_id','companies.name as company_name','headquarters.name as headquarter_name', 'users.name as user_name', 'users.surname as user_surname','offers.is_daw as offer_is_daw', 'offers.status as offer_status')
                ->get();

            return response()->json($offers, Response::HTTP_OK);
        }

        // Función para crear ofertas FUNCION
        public function store_offer(Request $request)
        {
            // Cogemos los datos que nos interesa
            $data = $request->only(
                'offer_is_daw',
                'offer_status',
                'headquarter_id',
                'user_id'
            );

            // Hacemos las validaciones
            $validator = Validator::make($data, [
                'offer_is_daw' => 'required|boolean',
                'offer_status' => 'required|string',
                'headquarter_id'=> 'required|numeric',
                'user_id' => 'required|numeric' 
            ]);

            // Si las validaciones fallan devolvemos el error
            if ($validator->fails()) {
                return response()->json(['error' => $validator->messages()], Response::HTTP_BAD_REQUEST);
            }

            // Convertimos el campo offer_status a una cadena JSON válida
            $status = json_encode($request->offer_status);

            // Creamos la oferta
            $offer = Offer::create([
                'is_daw' => $request->offer_is_daw,
                'status' => $status,
                'headquarter_id'=> $request->headquarter_id,
                'user_id' => $request->user_id
            ]);

            // Devolvemos el JSON
            return response()->json([
                'message' => 'Oferta creada',
                'offer' => $offer,
            ], Response::HTTP_OK);
        }

        // Funcion para actualizar una sede FUNCIONA
        public function update_offer(Request $request)
        {
            // Cogemos los datos que nos interesa
            $data = $request->only(
                'offer_id',
				/*
                'offer_is_daw',
				*/
                'offer_status',
				/*
                'headquarter_id',
                'user_id'
				*/
            );

            // Hacemos las validaciones
            $validator = Validator::make($data, [
                /*'offer_is_daw' => 'required|boolean',*/
                'offer_status' => 'required|string',
				/*
                'headquarter_id'=> 'required|numeric',
                'user_id' => 'required|numeric' */
            ]);
        
            // Si la validación falla mostramos el mensaje de error
            if ($validator->fails()) {
                return response()->json(['error' => $validator->messages()], Response::HTTP_BAD_REQUEST);
            }

            // Convertimos el campo offer_status a una cadena JSON válida
            $status = json_encode($request->offer_status);
        
            // Actualizamos los datos de la empresa
			
            $offer = Offer::findOrFail($request->offer_id);
			/*
            $offer->is_daw = $request->offer_is_daw;
			*/
            $offer->status = $status;
			/*
            $offer->headquarter_id = $request->headquarter_id;
            $offer->user_id = $request->user_id;
			*/
            $offer->save();

            // Actualizamos la empresa
            return response()->json([
                'message' => 'Sede actualizada',
                'offer' => $offer,
            ], Response::HTTP_OK);
        }

        // Funcion para eliminar una oferta
        public function destroy_offer ($id){
            //Buscamos la empresa
            $offer = Offer::findOrfail($id);

            //Eliminamos la empresa
            $offer->delete();

            //Devolvemos la respuesta
            return response()->json([
            'message' => 'Oferta eliminada correctamente'
            ], Response::HTTP_OK);
        }
    }


    
