<?php
    namespace App\Http\Controllers;
    use App\Http\Controllers\Controller;
    use JWTAuth;
    use App\Models\User;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Tymon\JWTAuth\Exceptions\JWTException;
    use Symfony\Component\HttpFoundation\Response;
    use Illuminate\Support\Facades\Validator;

    class AuthController extends Controller
    {
        //Función que utilizaremos para registrar al usuario
        public function register(Request $request){

            //Indicamos que solo queremos recibir name, email y
            // password de la request
            $data = $request->only('name', 'surname', 'email', 'password');

            //Realizamos las validaciones
            $validator = Validator::make($data, [
                'name' => 'required|string|min:2|max:50',
                'surname' => 'required|string|min:2|max:50',
                'email' => 'required|email|unique:users',
                'is_admin' => 'nullable|boolean', // nullable para que no sea necesario que se rellene
                'password' => 'required|string|min:6|max:50'
            ]);

            //Devolvemos un error si fallan las validaciones
            if ($validator->fails()) {
                return response()->json(['error' =>
                $validator->messages()], 400);
            }

            //Creamos el nuevo usuario
            $user = User::create([
                'name' => $request->name,
                'surname' => $request->surname,
                'email' => $request->email,
                'is_admin' => $request->is_admin, // Si es true es un profesor sino es un estudiante (1=true 0=false)
                'password' => bcrypt($request->password)
            ]);

            //Nos guardamos el usuario y la contraseña para realizar la petición de token a JWTAuth
            $credentials = $request->only('email', 'password');

            //Devolvemos la respuesta con el token del usuario
            return response()->json([
                'message' => 'Usuario creado',
                'token' => JWTAuth::attempt($credentials),
                'user' => $user
                ], Response::HTTP_OK);
    
        }
    
        //Funcion que utilizaremos para hacer login
        public function authenticate(Request $request)
        {
            //Indicamos que solo queremos recibir email y password de la request
            $credentials = $request->only('email', 'password');

            //Validaciones
            $validator = Validator::make($credentials, [
                'email' => 'required|email',
                'password' => 'required|string|min:6|max:50'
            ]);

            //Devolvemos un error de validación en caso de fallo en las verificaciones
            if ($validator->fails()) {
                return response()->json(['error' =>
                $validator->messages()], 400);
            }

            //Intentamos hacer login
            try {
                if (!$token = JWTAuth::attempt($credentials)) {
                //Credenciales incorrectas.
                return response()->json([
                'message' => 'Login falló',
                ], 401);
                }
            } catch (JWTException $e) {
                //Error chungo
                return response()->json([
                'message' => 'Error',
                ], 500);
            }

            //Devolvemos el token
            return response()->json([
                'success' => true,
                'token' => $token,
                'user' => Auth::user()
            ]);
        }

        //Función que utilizaremos para eliminar el token y desconectar al usuario
        public function logout(Request $request)
        {
            //Validamos que se nos envie el token
            $validator = Validator::make($request->only('token'), [
                'token' => 'required'
            ]);

            //Si falla la validación
            if ($validator->fails()) {
                return response()->json(['error' =>
                $validator->messages()], 400);
            }

            try {
            //Si el token es valido eliminamos el token desconectando al usuario.
                JWTAuth::invalidate($request->token);
                return response()->json([
                    'success' => true,
                    'message' => 'Usuario desconectado'
                ]);
            } catch (JWTException $exception) {
                //Error chungo
                return response()->json([
                    'success' => false,
                    'message' => 'Error'
                ], Response::HTTP_INTERNAL_SERVER_ERROR);
            }
        }

        //Función que utilizaremos para obtener los datos del usuario y validar si el token ha expirado.
        public function getUser(Request $request)
        {
            //Validamos que la request tenga el token
            $this->validate($request, [
                'token' => 'required'
            ]);

            //Realizamos la autentificación
            $user = JWTAuth::authenticate($request->token);

            //Si no hay usuario es que el token no es valido o que ha expirado
            if(!$user)
                return response()->json([
                    'message' => 'Token invalido / token expirado',
                ], 401);

            //Devolvemos los datos del usuario si todo va bien.
            return response()->json(['user' => $user]);
        }
		
		public function index_users()
        {
            $users = User::all();
            return response()->json($users, Response::HTTP_OK);
        }
    }

    