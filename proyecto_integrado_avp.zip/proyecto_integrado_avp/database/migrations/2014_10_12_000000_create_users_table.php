<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');  // Nombre del usuario
            $table->string('surname');  // Nombre del usuario
            $table->string('email')->unique();   // Email del usuario
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');  // Contraseña del usuario
            $table->boolean('is_admin'); // Si es true es que es un profesor sino es un estudiante
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
