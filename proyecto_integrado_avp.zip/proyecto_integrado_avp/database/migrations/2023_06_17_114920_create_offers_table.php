<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOffersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offers', function (Blueprint $table) {
            $table->id();
            $table->boolean('is_daw');  // Si es true es DAW sino DAM
            $table->json('status')->default(json_encode(['aceptado', 'en curso', 'rechazado'])); // De este modo almacenamos los valores del campo status
            $table->UnsignedBigInteger('headquarter_id'); // Foreign key
            $table->foreign('headquarter_id')
                ->references('id')
                ->on('headquarters')
                ->onDelete('cascade');
            $table->UnsignedBigInteger('user_id'); // Foreign keys
            $table->foreign('user_id')
                ->references('id')
                ->on('users')
				->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offers');
    }
}