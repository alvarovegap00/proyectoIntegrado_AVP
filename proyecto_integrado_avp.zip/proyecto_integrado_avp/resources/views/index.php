<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Proyecto</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
        <!-- <link rel="stylesheet" href="{{asset ('index_style.css')}}"> -->
        <!-- <script src="index.js"></script> -->
        <!-- Para que se mueva el carrusel -->
        <script>
 
        </script>
    <style>
        .col{
    margin-top: 2%;
    /* background-color: rgba(245, 245, 245, 0.391); */
    display: block;
}

.enlace{
    display: flex;
    justify-content: center;
}

.header a{
    text-decoration: none;
}

#carousel {
    width:50%;
    height: 10%;
    margin-right: 20%;
    margin-left: 20%;
    margin-top: 2%;
    /* ANIMACION */
    -webkit-animation-name: slideInLeft;
    animation-name: slideInLeft;
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
    }
    @-webkit-keyframes slideInLeft {
    0% {
    -webkit-transform: translateX(-100%);
    transform: translateX(-100%);
    visibility: visible;
    }
    100% {
    -webkit-transform: translateX(0);
    transform: translateX(0);
    }
    }
    @keyframes slideInLeft {
    0% {
    -webkit-transform: translateX(-100%);
    transform: translateX(-100%);
    visibility: visible;
    }
    100% {
    -webkit-transform: translateX(0);
    transform: translateX(0);
    }
}

img {
    width: 30%;
    height: 20%;
}

#cabecera{
    margin-left: 5%;
    margin-right: 5%;
    margin-top: .5%;
    /* ANIMACION */
    -webkit-animation-name: slideInDown;
    animation-name: slideInDown;
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
    }
    @-webkit-keyframes slideInDown {
    0% {
    -webkit-transform: translateY(-100%);
    transform: translateY(-100%);
    visibility: visible;
    }
    100% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
    }
    }
    @keyframes slideInDown {
    0% {
    -webkit-transform: translateY(-100%);
    transform: translateY(-100%);
    visibility: visible;
    }
    100% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
    }
    
}

#descripcion{
    margin-top: 2%;
    margin-left: 10%;
    margin-right: 10%;
    margin-bottom: 5%;
    /* ANIMACION */
    -webkit-animation-name: slideInUp;
    animation-name: slideInUp;
    -webkit-animation-duration: 1s;
    animation-duration: 1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
    }
    @-webkit-keyframes slideInUp {
    0% {
    -webkit-transform: translateY(100%);
    transform: translateY(100%);
    visibility: visible;
    }
    100% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
    }
    }
    @keyframes slideInUp {
    0% {
    -webkit-transform: translateY(100%);
    transform: translateY(100%);
    visibility: visible;
    }
    100% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
    }
}

#cabecera a {
    color: rgb(0, 0, 0);
    
}

#container{
    background-color: rgba(0, 0, 0, 0);
    
}

#nombre_pag{
    font-family: fantasy;
}





    </style>
    </head>
    <body>

        <!-- Input groups / floating labels / validation bootstrap para el login y register -->

        <!-- Spinners para cargar en bootstrap -->

        <!-- CABECERA -->
        <nav class="navbar navbar-expand-lg bg-light" id="cabecera">
            <div class="container-fluid rounded" id="container">
              <a class="navbar-brand" href="index.html" id="nombre_pag">RuralHouse</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                  </li>
                  <li class="nav-item">
                    <!-- Este link lleva a la descripción de abajo -->
                    <a class="nav-link" href="#descripcion">Sobre nosotros</a>
                </ul>

                <!-- Boton que abre un pop up para registrarse/iniciar sesion -->
                <a href="login/login.html" class="btn btn-outline-primary m-1" data-bs-toggle="modal" data-bs-target="#user_form">
                    Acceso usuario
                </a>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
              </div>
            </div>
          </nav>

        <!-- PUEBLOS -->
        <!-- Cazorla, Olvera, Potes Santillana del Mar, Aínsa-Sobrarbe, Singüenza -->

        <!-- CAROUSEL -->
        <!-- COGER IMAGENES DE BUENA CALIDAD -->
        <div id="carousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carousel" data-slide-to="0" class="active"></li>
                <li data-target="#carousel" data-slide-to="1"></li>
                <li data-target="#carousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="card">
                        <!-- Va a llevar a una pagina con un par de casas pero solo funciona la 1º -->
                        <a href="cazorla/busqueda_cazorla/busqueda_cazorla.html">
                            <img src="{{asset ('cazorla_index.jpg')}}" class="card-img-top rounded" alt="...">
                        </a>
                        <div class="card-body">
                            <h5 class="card-title">Cazorla</h5>
                            <p class="card-text">Cazorla es una localidad y municipio español situado en la parte septentrional de la comarca de Sierra de Cazorla, en la provincia de Jaén</p>
                            <div class="enlace">
                                <a href="{{asset ('cazorla/busqueda_cazorla/busqueda_cazorla.html')}}" class="btn btn-primary m-1">Más información</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card">
                        <a href="olvera/busqueda_olvera/busqueda_olvera.html">
                            <img src="images/Olvera_index.jpg" class="card-img-top rounded" alt="...">
                        </a>
                        <div class="card-body">
                            <h5 class="card-title">Olvera</h5>
                            <p class="card-text">Olvera es un municipio y localidad española de la provincia de Cádiz, en la comunidad autónoma de Andalucía. Está incluido en la comarca de la Sierra de Cádiz, y dentro del partido judicial de Arcos de la Frontera</p>
                            <div class="enlace">
                                <a href="olvera/busqueda_olvera/busqueda_olvera.html" class="btn btn-primary">Más información</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card">
                        <a href="potes/busqueda_potes/busqueda_potes.html">
                            <img src="images/potes_index.jpg" class="card-img-top rounded" alt="...">
                        </a>
                        <div class="card-body">
                            <h5 class="card-title">Potes</h5>
                            <p class="card-text">Potes es un municipio de España perteneciente a la comunidad autónoma de Cantabria. Está situado en el centro de la comarca de Liébana de la cual es capital. Este Ayuntamiento limita al norte con Cillorigo de Liébana, al oeste con Camaleño, al sur con Vega de Liébana y al este con Cabezón de Liébana</p>
                            <div class="enlace">
                                <a href="potes/busqueda_potes/busqueda_potes.html" class="btn btn-primary">Más información</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Anterior</span>
            </a>
            <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Siguiente</span>
            </a>
        </div>
        <!-- Añadir una breve descripción de la pagina web -->
        <div id="descripcion">
            <h3>Sobre nosotros</h3>
            <p>
                <strong>RuralHouse</strong> es la página web número 1 dedicada al alquiler de casas rurales en los mejores lugares de España.
                En <strong>RuralHouse</strong> podrás encontrar casas, hostales, establecimientos por toda España al mejor precio y con las mejores instalaciones. Contamos con la confianza
                y el respaldo de que <strong>el 90% de nuestros clientes repetirían experencia con nostros</strong>, e inumerables valoraciones positivas en la mayoría de webs de viajes.
                Así que no dudes en informarte de nuestras ofertas y establecimientos disponibles.
            </p>
            <!-- Ponemos un listado con las carcterísticas de la casa (li) -->
        </div>

        <!-- poner footer -->
    </body>
</html>