var token = localStorage.getItem('token');

// ----------------------------- DESLOGUEARSE -----------------------------
// Verificar si el usuario ha iniciado sesión
function checkLoggedIn() {
    // Obtener el token del local storage
    var token = localStorage.getItem('token');
    
    // Verificar si el token existe y no está vacío
    if (token && token !== '') {
      // El usuario ha iniciado sesión
      return true;
    } else {
      // El usuario no ha iniciado sesión
      return false;
    }
  }
  
// Redireccionar a la página de inicio de sesión si el usuario no ha iniciado sesión
function redirectToLogin() {
    window.location.href = '../index.html';
}

// Verificar el estado de inicio de sesión antes de cargar la página
function checkAccess() {
    if (!checkLoggedIn()) {
        alert("No tiene permisos para acceder a esta página");
        // El usuario no ha iniciado sesión, redirigir a la página de inicio de sesión
        redirectToLogin();
    }
}

// Obtener el botón de desloguear por su ID
var logoutButton = document.getElementById('logout');

// Función para realizar el logout
function logout() {
  // Obtener el token del local storage
  var token = localStorage.getItem('token');
  
  // Verificar si el token existe y no está vacío
    if (token && token !== '') {
        if (confirm("¿Desea desloguearse?")){
            // Realizar la petición de logout al servidor
            fetch('http://127.0.0.1:8000/api/logout', {
                method: 'POST',
                headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token,
                // 'token': token
                }
            })
            .then(function(response) {
                // Verificar si la respuesta fue exitosa
                if (response.ok) {
                    // Eliminar el token del local storage
                    localStorage.removeItem('token');
                    // Mostrar mensaje de deslogueo exitoso
                    alert('Has sido deslogueado correctamente');
                    // Redireccionar a la página de inicio
                    window.location.href = '../index.html';
                } else {
                    // Mostrar mensaje de error
                    alert('Error al desloguear');
                }
            })
            .catch(function(error) {
                // Mostrar mensaje de error
                alert('Error al desloguear');
            });
        }
    } else {
    // Mostrar mensaje de error si el token no existe
    alert('Error al desloguear');
  }
}

// ----------------------------- COGER LOS DATOS DEL USUARIO -----------------------------
// Función para obtener los datos del usuario
function getUserData() {
    console.log("llega");
    // Obtener el token del local storage
    var token = localStorage.getItem('token');
  
    // Verificar si el token existe y no está vacío
    if (token && token !== '') {
      // Realizar la petición al servidor para obtener los datos del usuario
      fetch('http://127.0.0.1:8000/api/get-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ token: token })

      })
      .then(function(response) {
        // Verificar si la respuesta fue exitosa
        if (response.ok) {
          // Obtener los datos del usuario de la respuesta
          return response.json();
        } else {
          // Mostrar mensaje de error
          alert('Error al obtener los datos del usuario');
          throw new Error('Error en la respuesta del servidor');
        }
      })
      .then(function(data) {
        // Verificar si se recibieron los datos del usuario correctamente
        if (data && data.user) {
          // Mostrar los datos del usuario en la consola
          console.log('Datos del usuario:', data.user);
          // Realizar las operaciones necesarias con los datos del usuario
          // ...
        } else {
          // Mostrar mensaje de error
          alert('Error al obtener los datos del usuario');
        }
      })
      .catch(function(error) {
        // Mostrar mensaje de error
        console.log(error);
        alert('Error al obtener los datos del usuario');
      });
    } else {
      // Mostrar mensaje de error si el token no existe
      alert('Error al obtener los datos del usuario');
    }
  }

window.onload = function() {
    // Para coger los datos del usuario
    getUserData();
    
    checkAccess();

    // Para desloguear
    document.getElementById('logout').onclick = logout;

}