var url = "http://127.0.0.1:8000/api/login"; // Variable global para que la url aparezca en todo el código

var datos;

var parametros = {};

window.onload = function (){

    document.getElementById('login').onclick = login;
}

// Función para realizar el inicio de sesión
function login() {
    // Obtener los valores de email y password
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
  
    // Crear el objeto de datos para enviar al servidor
    var data = {
      email: email,
      password: password
    };
  
    // Realizar la petición de inicio de sesión al servidor
    fetch('http://127.0.0.1:8000/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(function(response) {
      // Verificar si la respuesta fue exitosa
      if (response.ok) {
        // Obtener el token de la respuesta
        return response.json();
      } else {
        // Mostrar mensaje de error
        alert('Error al iniciar sesión');
        throw new Error('Error en la respuesta del servidor');
      }
    })
    .then(function(data) {
      // Verificar si se recibió el token correctamente
      if (data && data.success && data.token) {
            // Almacenar el token en el local storage
            localStorage.setItem('token', data.token);
            alert("Ha iniciado sesión correctamente");
            // Redireccionar a la página de inicio
            window.location.href = 'inicio/inicio.html';
      } else {
        // Mostrar mensaje de error
        alert('Error al iniciar sesión');
      }
    })
    .catch(function(error) {
      // Mostrar mensaje de error
      console.log(error);
      alert('Error al iniciar sesión');
    });
  }
  
  // Ejecutar la función de inicio de sesión cuando se hace clic en el botón
  