window.onload = function() {
    console.log("llega");
    // Obtiene el formulario de registro
    var form = document.querySelector('form');
  
    // Agrega un evento de escucha para el envío del formulario
    form.addEventListener('submit', function(event) {
      event.preventDefault(); // Evita que el formulario se envíe de forma predeterminada
  
      // Obtiene los valores de los campos de entrada
      var name = document.getElementById('name').value;
      var surname = document.getElementById('surname').value;
      var email = document.getElementById('email').value;
      var password = document.getElementById('password').value;
      var isAdmin = document.getElementById('is_admin').checked;
  
      // Crea un objeto con los datos del usuario
      var user = {
        name: name,
        surname: surname,
        email: email,
        password: password,
        is_admin: isAdmin
      };
  
      // Realiza la solicitud de registro al servidor
      fetch('http://127.0.0.1:8000/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(user)
      })
      .then(function(response) {
        if (response.ok) {
          return response.json();
        } else {
            console.log('Error en la solicitud de registro')
          throw new Error('Error en la solicitud de registro');
        }
      })
      .then(function(data) {
        // Registro exitoso
        alert('Usuario registrado con éxito')
        console.log('Usuario registrado:', data.user);
  
        // Almacena el token en el almacenamiento local
        localStorage.setItem('token', data.token);
  
        // Muestra un mensaje de registro exitoso
        alert('Registro exitoso');
  
        // Redirige a la página de inicio
        window.location.href = '../inicio/inicio.html';
      })
      .catch(function(error) {
        // Error en el registro
        console.error('Error en el registro:', error);
        alert('Error en el registro');
      });
    });
  };
  