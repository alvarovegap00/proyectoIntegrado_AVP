var token = localStorage.getItem('token');

// ----------------------------- DESLOGUEARSE -----------------------------
// Verificar si el usuario ha iniciado sesión
function checkLoggedIn() {
    // Obtener el token del local storage
    var token = localStorage.getItem('token');
    
    // Verificar si el token existe y no está vacío
    if (token && token !== '') {
      // El usuario ha iniciado sesión
      return true;
    } else {
      // El usuario no ha iniciado sesión
      return false;
    }
  }
  
// Redireccionar a la página de inicio de sesión si el usuario no ha iniciado sesión
function redirectToLogin() {
    window.location.href = '../index.html';
}

// Verificar el estado de inicio de sesión antes de cargar la página
function checkAccess() {
    if (!checkLoggedIn()) {
        alert("No tiene permisos para acceder a esta página");
        // El usuario no ha iniciado sesión, redirigir a la página de inicio de sesión
        redirectToLogin();
    }
}

// Obtener el botón de desloguear por su ID
var logoutButton = document.getElementById('logout');

// Función para realizar el logout
function logout() {
  // Obtener el token del local storage
  var token = localStorage.getItem('token');
  
  // Verificar si el token existe y no está vacío
    if (token && token !== '') {
        if (confirm("¿Desea desloguearse?")){
            // Realizar la petición de logout al servidor
            fetch('http://127.0.0.1:8000/api/logout', {
                method: 'POST',
                headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token,
                // 'token': token
                }
            })
            .then(function(response) {
                // Verificar si la respuesta fue exitosa
                if (response.ok) {
                    // Eliminar el token del local storage
                    localStorage.removeItem('token');
                    // Mostrar mensaje de deslogueo exitoso
                    alert('Has sido deslogueado correctamente');
                    // Redireccionar a la página de inicio
                    window.location.href = '../index.html';
                } else {
                    // Mostrar mensaje de error
                    alert('Error al desloguear');
                }
            })
            .catch(function(error) {
                // Mostrar mensaje de error
                alert('Error al desloguear');
            });
        }
    } else {
    // Mostrar mensaje de error si el token no existe
    alert('Error al desloguear');
  }
}

// ----------------------------- COGER LOS DATOS DEL USUARIO -----------------------------
// Función para obtener los datos del usuario
function getUserData() {
    console.log("llega");
    // Obtener el token del local storage
    var token = localStorage.getItem('token');
  
    // Verificar si el token existe y no está vacío
    if (token && token !== '') {
      // Realizar la petición al servidor para obtener los datos del usuario
      fetch('http://127.0.0.1:8000/api/get-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ token: token })

      })
      .then(function(response) {
        // Verificar si la respuesta fue exitosa
        if (response.ok) {
          // Obtener los datos del usuario de la respuesta
          return response.json();
        } else {
          // Mostrar mensaje de error
          alert('Error al obtener los datos del usuario');
          throw new Error('Error en la respuesta del servidor');
        }
      })
      .then(function(data) {
        // Verificar si se recibieron los datos del usuario correctamente
        if (data && data.user) {
          // Mostrar los datos del usuario en la consola
          console.log('Datos del usuario:', data.user);
          // Realizar las operaciones necesarias con los datos del usuario
          // ...
        } else {
          // Mostrar mensaje de error
          alert('Error al obtener los datos del usuario');
        }
      })
      .catch(function(error) {
        // Mostrar mensaje de error
        console.log(error);
        alert('Error al obtener los datos del usuario');
      });
    } else {
      // Mostrar mensaje de error si el token no existe
      alert('Error al obtener los datos del usuario');
    }
  }

window.onload = function() {
    var token = localStorage.getItem('token');
    // Para coger los datos del usuario
    getUserData();
    
    checkAccess();

    // Para desloguear
    document.getElementById('logout').onclick = logout;
    
    var url = "http://127.0.0.1:8000/api/offers";

    fetch(url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            'Authorization': 'Bearer ' + token
        }

    })
    .then(respuesta => respuesta.json())
    .then(datos => pintaDatos(datos))
    .catch(e => console.error("Error al recoger los datos --> ", e));

    /*
    // Para sacar las empresas:
    fetch("http://127.0.0.1:8000/api/companies", {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(respuesta => respuesta.json())
    .then(datos => datosEmpresa(datos))
    .catch(e => console.error("Error al recoger los datos --> ", e));
    */

    // Para sacar las sedes:
    fetch('http://127.0.0.1:8000/api/headquarters', {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            'Authorization': 'Bearer ' + token
        }

    })
    .then(respuesta => respuesta.json())
    .then(datos => datosSede(datos))
    .catch(e => console.error("Error al recoger los datos --> ", e));

    // Para sacar los usuarios:
    fetch('http://127.0.0.1:8000/api/index_user', {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            'Authorization': 'Bearer ' + token
        }

    })
    .then(respuesta => respuesta.json())
    .then(datos => datosUser(datos))
    .catch(e => console.error("Error al recoger los datos --> ", e));
    
    // Para mostrar el formulario
    document.getElementById("btn_crear_oferta").onclick = mostrarForm;

    // Para ocultar el formulario
    document.getElementById("cancelar").onclick = ocultaForm;

    
    // Para crear una empresa
    document.getElementById("crear_oferta").onclick = crearOferta;


}

function pintaDatos(datos) {
    var tbody = document.getElementById("offers");
    tbody.innerHTML = "";

    datos.forEach((oferta) => {
        var fila = document.createElement("tr");

        var offer_id = document.createElement("td");
        offer_id.textContent = oferta.offer_id;
        fila.appendChild(offer_id);

        var nombreEmpresaColumna = document.createElement("td");
        nombreEmpresaColumna.textContent = oferta.company_name;
        fila.appendChild(nombreEmpresaColumna);

        var headquarter_name = document.createElement("td");
        headquarter_name.textContent = oferta.headquarter_name;
        fila.appendChild(headquarter_name);

        var user_name = document.createElement("td");
        user_name.textContent = (oferta.user_name+ " "+oferta.user_surname);
        fila.appendChild(user_name);

        var offer_is_daw = document.createElement("td");
        if ( oferta.offer_is_daw == 1){
            offer_is_daw.textContent = 'DAW';
        }else{
            offer_is_daw.textContent = 'DAM';
        }
        fila.appendChild(offer_is_daw);    

        status_bien = oferta.offer_status.replace('"', "");
        status_bien = status_bien.replace('"', "");
        console.log("estado de la oferta: "+status_bien);
        
        var status = document.createElement("td");
        status.textContent = status_bien;
        fila.appendChild(status);

        var accionesColumna = document.createElement("td");

        
        
        var botonActualizar = document.createElement("button");
        botonActualizar.textContent = "Actualizar";
        botonActualizar.className = "btn btn-primary";
        botonActualizar.setAttribute("id", "btn_actualizar");
        botonActualizar.dataset.offer_id = oferta.offer_id;
        // Metemos toda la info en el dataset
        botonActualizar.dataset.company_name =oferta.company_name;
        botonActualizar.dataset.headquarter_name = oferta.headquarter_name;
        botonActualizar.dataset.user_name = (oferta.user_name+ " "+oferta.user_surname);
        botonActualizar.dataset.offer_is_daw = oferta.offer_is_daw;
        botonActualizar.dataset.status = status_bien;
        botonActualizar.onclick = volcarDatosUpdate;


        var botonEliminar = document.createElement("button");
        botonEliminar.textContent = "Eliminar";
        botonEliminar.className = "btn btn-danger";
        botonEliminar.dataset.id = oferta.offer_id;
        botonEliminar.onclick = eliminarSede;

        accionesColumna.appendChild(botonActualizar);
        accionesColumna.appendChild(botonEliminar);

        fila.appendChild(accionesColumna);

        tbody.appendChild(fila);
    });
}


// Función para mostrar el formulario
function mostrarForm () {
    // Cogemos el formulario
    var formualrio = document.getElementById("formulario");
    // Mostramos el formulario
    formualrio.style.display = 'inline';

    // Ocultamos el botón que muestra el formulario
    var btn_mostrar_form = document.getElementById("create_oferta");
    btn_mostrar_form.style.display = 'none';

    document.getElementById("sedes").disabled = false;
    document.getElementById("usuarios").disabled = false;
    document.getElementById("is_daw").disabled = false;
}

function ocultaForm (){
    // Cogemos el formulario
    var formualrio = document.getElementById("formulario");
    // Ocultamos el formulario
    formualrio.style.display = 'none';

    // Mostramos el botón que muestra el formulario
    var btn_mostrar_form = document.getElementById("create_oferta");
    btn_mostrar_form.style.display = 'inline';

    document.getElementById("sedes").disabled = false;
    document.getElementById("usuarios").disabled = false;
    document.getElementById("is_daw").disabled = false;
}

// Función para mostar el formulario para 
function mostrarFormUpdate (){
    // Cogemos el formulario
    var formualrio = document.getElementById("formulario");
    // Mostramos el formulario
    formualrio.style.display = 'inline';

    // Ocultamos el boton de crear empresa:
    var boton_crear = document.getElementById("create_oferta");
    boton_crear.style.display = 'none';

    // Ponemos el texto del botón con el valor Actualizar
    if (document.getElementById("crear_oferta")){
        var boton = document.getElementById("crear_oferta");
        boton.innerHTML = "Actualizar";
    }
    
}

/*
// Funcion para coger todas las empresas y mostrarlas en el formulario
function datosEmpresa (datos) {
    var etiqueta_select = document.getElementById("empresas");
    etiqueta_select.innerHTML = "";

    datos.forEach((empresa) => {
        var valor = document.createElement("option");
        valor.value = empresa.id;
        valor.textContent = empresa.name;
        valor.dataset.company_id = empresa.id;
        valor.dataset.company_name = empresa.name;
        etiqueta_select.appendChild(valor)
    });
}
*/

// Funcion para coger todas las sedes y mostrarlas en el formulario
function datosSede (datos) {
    var etiqueta_select = document.getElementById("sedes");
    etiqueta_select.innerHTML = "";

    datos.forEach((sede) => {
        var valor = document.createElement("option");
        valor.value = sede.id;
        valor.textContent = sede.headquarter_name;
        valor.dataset.headquarter_id = sede.id;
        valor.dataset.headquarter_name =sede.headquarter_name;
        etiqueta_select.appendChild(valor)
    });
}

// Funcion para coger todos los usuarios y mostrarlos en el formulario
function datosUser (datos) {
    var etiqueta_select = document.getElementById("usuarios");
    etiqueta_select.innerHTML = "";

    datos.forEach((usuario) => {
        var valor = document.createElement("option");
        valor.value = usuario.id;
        valor.textContent = (usuario.name+" "+usuario.surname);
        valor.dataset.usuario_id = usuario.id;
        valor.dataset.usuario_name = (usuario.name+" "+usuario.surname);
        etiqueta_select.appendChild(valor)
    });
}

/*
function volcarDatosUpdate (e){
    // Cogemos los datos de la oferta y lo pintamos en los campos correspondientes
    e.preventDefault();

    // Llamamos a la función para mostrar el formulario
    mostrarFormUpdate();

    // Ponemos disabled los campos que no se pueden actualizar.
    //Sede
    document.getElementById("sedes").disabled = true;
    // Usuario
    document.getElementById("usuarios").disabled = true;
    // Tipo de oferta
    document.getElementById("is_daw").disabled = true;

    console.log("e: "+this.dataset.offer_id);

    
    // Rellenamos la sede 
    var headquarter_name = document.getElementById("sedes");
    // Le damos el valor del estudiante que le hemos hecho click
    headquarter_name.forEach(sede => {
        if (sede.text == this.dataset.headquarter_name){
            sede.selected = true;
        }
    });
    // headquarter_name.value = this.dataset.headquarter_name;
    // headquarter_name.selected = true;

    // Rellenamos el usuario
    var user_name = document.getElementById("usuarios");
    // Le damos el valor del estudiante que le hemos hecho click
    user_name.forEach(user => {
        if (user.text == this.dataset.user_name){
            user.selected = true;
        }
    });
    // user_name.value = this.dataset.user_name;
    // user_name.selected = true;

    // Rellenamos is_daw
    var is_daw = document.getElementById("is_daw");
    is_daw.forEach(status => {
        if(status.value == this.dataset.is_daw){
            status.selected = true;
        }
    });
    /*
    // Le damos el valor del estudiante que le hemos hecho click
    if (this.dataset.is_daw == 1){
        // is_daw.value = 'DAW';
        is_daw.selected = true;
    }else{
        // is_daw.value = 'DAM';
        is_daw.selected = true;
    }
    

    // Rellenamos el estado
    var status = document.getElementById("status");
    // Le damos el valor del estudiante que le hemos hecho click
    // status.value = this.dataset.status;
    status.selected = true;


    // Cambiamos el id del boton para hacer la actualización ya que en el windows on load lo usamos para crear un estudiante
    if (document.getElementById("crear_oferta")){
        boton = document.getElementById("crear_oferta");
        boton.setAttribute('id', 'btn_actualizar');
    }

    // Pasamos el id del estudiante a traves de un dataset
    boton.dataset.id = this.dataset.id;

    // Llamamos a la función actualizar cundo haga click en actualizar:
    boton.onclick = actualizarOferta;
}
*/

function volcarDatosUpdate(e) {
    e.preventDefault();
  
    // Mostrar el formulario de actualización
    mostrarFormUpdate();

    // Cambiamos el id del boton para hacer la actualización ya que en el windows on load lo usamos para crear un estudiante
    if (document.getElementById("crear_oferta")){
        boton = document.getElementById("crear_oferta");
        boton.setAttribute('id', 'actualizar');
    }

    console.log("id oferta: "+this.dataset.offer_id);
  
    // Deshabilitar campos que no se pueden actualizar
    document.getElementById("sedes").disabled = true;
    document.getElementById("usuarios").disabled = true;
    document.getElementById("is_daw").disabled = true;

    var boton_actualizar = document.getElementById("actualizar");
    boton_actualizar.dataset.offer_id = this.dataset.offer_id;
    boton_actualizar.dataset.offer_status = this.dataset.status;
  
    // Obtener los valores de los datos de la oferta
    var headquarter_name = this.dataset.headquarter_name;
    var user_name = this.dataset.user_name;
    var is_daw = this.dataset.offer_is_daw;
    var status = this.dataset.status;

    console.log("is_daw: "+is_daw);
  
    // Rellenar el select de sedes
    var sedeSelect = document.getElementById("sedes");
    Array.from(sedeSelect.options).forEach(function (option) {
      if (option.text === headquarter_name) {
        option.selected = true;
      }
    });
  
    // ------------------- NO SE RELLEBA BIEN EL ESTADO -------------------

    // Rellenar el select de usuarios
    var usuarioSelect = document.getElementById("usuarios");
    Array.from(usuarioSelect.options).forEach(function (option) {
      if (option.text === user_name) {
        option.selected = true;
      }
    });
  
    // Rellenar el select de tipo de oferta
    var tipoOfertaSelect = document.getElementById("is_daw");
    console.log("status: "+tipoOfertaSelect);
    Array.from(tipoOfertaSelect.options).forEach(function (option) {
      if (option.value == is_daw) {
        option.selected = true;
      }
    });
  
    // Rellenar el select de estado
    var estadoSelect = document.getElementById("status");
    Array.from(estadoSelect.options).forEach(function (option) {
      if (option.value == status) {
        option.selected = true;
      }
    });
  
    
  
    // Asignar el evento de clic para actualizar la oferta
    boton.onclick = actualizarOferta;
  }
  

// Función para crear una empresa
function crearOferta(e) {

    e.preventDefault();

    // Obtener los valores del formulario
    var headquarter_id = document.getElementById("sedes").value;
    var user_id = document.getElementById("usuarios").value;
    var is_daw = document.getElementById("is_daw").value;
    var status = document.getElementById("status").value;

    console.log("usuario: "+user_id);
    console.log("sedes: "+headquarter_id);
    console.log("is_daw: "+is_daw);
    console.log("status: "+status);
    
    // Crear el objeto de la empresa
    var oferta = {
        offer_is_daw: is_daw,
        offer_status: status,
        headquarter_id: headquarter_id,
        user_id: user_id
    };
    
    // Enviar el objeto a través de una petición POST
    fetch('http://127.0.0.1:8000/api/offers',{
        method: "POST",
        body: JSON.stringify(oferta),
        headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + token
        }
    })
        .then(respuesta => respuesta.json())
        .then(datos => {
            console.log("Oferta creada: ", datos);

            // Ocultamos el formulario
            ocultaForm();
            
            // Recargamos la página para mostrar la empresa creada
            location.reload();
        })
        .catch(e => console.error("Error al crear la oferta: ", e));
}

// Funcion para actualizar una empresa
function actualizarOferta(e) {
    e.preventDefault();

    // Obtener los valores del formulario
    var status = document.getElementById("status").value;

    console.log("status actualizar: "+status);
    console.log("id de la oferta: "+this.dataset.offer_id);

    // Crear el objeto de la empresa
    var oferta = {
        offer_id: this.dataset.offer_id,
        offer_status: status,
    };
    
    // Enviar el objeto a través de una petición POST
    fetch('http://127.0.0.1:8000/api/offers',{
        method: "PUT",
        body: JSON.stringify(oferta),
        headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + token
        }
    })
        .then(respuesta => respuesta.json())
        .then(datos => {
            console.log("Oferta actualizada: ", datos);
            document.getElementById("sedes").disabled = false;
            document.getElementById("usuarios").disabled = false;
            document.getElementById("is_daw").disabled = false;

            // Ocultamos el formulario
            ocultaForm();
            
            // Recargamos la página para mostrar la empresa creada
            location.reload();
        })
        .catch(e => console.error("Error al crear la sede: ", e));
}


// Funcion para eliminar una empresa
function eliminarSede(event) {
    var oferta_id = event.target.dataset.id;
    
    if(confirm("Desea eliminar la oferta con id: "+oferta_id)){
        // Enviar una petición DELETE para eliminar la sede
        fetch('http://127.0.0.1:8000/api/offers/' + oferta_id, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            }
        })
            .then(respuesta => {
                alert("Oferta eliminada con éxito");  
                console.log("Empresa eliminada");
                location.reload();
            })
            .catch(e => console.error("Error al eliminar la sede: ", e));
        }
}

