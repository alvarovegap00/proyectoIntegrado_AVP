var token = localStorage.getItem('token');

// Verificar si el usuario ha iniciado sesión
function checkLoggedIn() {
    // Obtener el token del local storage
    var token = localStorage.getItem('token');
    
    // Verificar si el token existe y no está vacío
    if (token && token !== '') {
      // El usuario ha iniciado sesión
      return true;
    } else {
      // El usuario no ha iniciado sesión
      return false;
    }
  }
  
// Redireccionar a la página de inicio de sesión si el usuario no ha iniciado sesión
function redirectToLogin() {
    window.location.href = '../index.html';
}

// Verificar el estado de inicio de sesión antes de cargar la página
function checkAccess() {
    if (!checkLoggedIn()) {
        alert("No tiene permisos para acceder a esta página");
        // El usuario no ha iniciado sesión, redirigir a la página de inicio de sesión
        redirectToLogin();
    }
}

// Obtener el botón de desloguear por su ID
var logoutButton = document.getElementById('logout');

// Función para realizar el logout
function logout() {
  // Obtener el token del local storage
  var token = localStorage.getItem('token');
  
  // Verificar si el token existe y no está vacío
    if (token && token !== '') {
        if (confirm("¿Desea desloguearse?")){
            // Realizar la petición de logout al servidor
            fetch('http://127.0.0.1:8000/api/logout', {
                method: 'POST',
                headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token,
                // 'token': token
                },
                body: JSON.stringify({ token: token })
            })
            .then(function(response) {
                // Verificar si la respuesta fue exitosa
                if (response.ok) {
                    // Eliminar el token del local storage
                    localStorage.removeItem('token');
                    // Mostrar mensaje de deslogueo exitoso
                    alert('Has sido deslogueado correctamente');
                    // Redireccionar a la página de inicio
                    window.location.href = '../index.html';
                } else {
                    // Mostrar mensaje de error
                    alert('Error al desloguear');
                }
            })
            .catch(function(error) {
                // Mostrar mensaje de error
                alert('Error al desloguear');
            });
        }
    } else {
    // Mostrar mensaje de error si el token no existe
    alert('Error al desloguear');
  }
}
  

window.onload = function() {
    var token = localStorage.getItem('token');

    checkAccess();

    // Para desloguear
    document.getElementById('logout').onclick = logout;

    var url = "http://127.0.0.1:8000/api/headquarters";

    fetch(url, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            'Authorization': 'Bearer ' + token
        }
    })
    .then(respuesta => respuesta.json())
    .then(datos => pintaDatos(datos))
    .catch(e => console.error("Error al recoger los datos --> ", e));


    // Para sacar las empresas:
    fetch("http://127.0.0.1:8000/api/companies", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            'Authorization': 'Bearer ' + token
        }
    })
    .then(respuesta => respuesta.json())
    .then(datos => datosEmpresa(datos))
    .catch(e => console.error("Error al recoger los datos --> ", e));

    // Para mostrar el formulario
    document.getElementById("btn_crear_sede").onclick = mostrarForm;

    // Para ocultar el formulario
    document.getElementById("cancelar").onclick = ocultaForm;

    // Para crear una empresa
    document.getElementById("crear_sede").onclick = crearSede;

}

function pintaDatos(datos) {
    var tbody = document.getElementById("headquarters");
    tbody.innerHTML = "";

    datos.forEach((sede) => {
        var fila = document.createElement("tr");

        var idColumna = document.createElement("td");
        idColumna.textContent = sede.id;
        fila.appendChild(idColumna);

        var nombreColumna = document.createElement("td");
        nombreColumna.textContent = sede.headquarter_name;
        fila.appendChild(nombreColumna);

        var nombreEmpresaColumna = document.createElement("td");
        nombreEmpresaColumna.textContent = sede.company_name;
        fila.appendChild(nombreEmpresaColumna);

        var accionesColumna = document.createElement("td");
        
        var botonActualizar = document.createElement("button");
        botonActualizar.textContent = "Actualizar";
        botonActualizar.className = "btn btn-primary";
        botonActualizar.dataset.id = sede.id;
        // Metemos toda la info en el dataset
        botonActualizar.dataset.headquarter_name = sede.headquarter_name;
        botonActualizar.dataset.company_name = sede.company_name;
        botonActualizar.dataset.company_id = sede.company_id;
        botonActualizar.onclick = volcarDatosUpdate;


        var botonEliminar = document.createElement("button");
        botonEliminar.textContent = "Eliminar";
        botonEliminar.className = "btn btn-danger";
        botonEliminar.dataset.id = sede.id;
        botonEliminar.onclick = eliminarSede;

        accionesColumna.appendChild(botonActualizar);
        accionesColumna.appendChild(botonEliminar);

        fila.appendChild(accionesColumna);

        tbody.appendChild(fila);
    });
}


// Función para mostrar el formulario
function mostrarForm () {
    // Cogemos el formulario
    var formualrio = document.getElementById("formulario");
    // Mostramos el formulario
    formualrio.style.display = 'inline';

    // Ocultamos el botón que muestra el formulario
    var btn_mostrar_form = document.getElementById("create_sede");
    btn_mostrar_form.style.display = 'none';
}

function ocultaForm (){
    // Cogemos el formulario
    var formualrio = document.getElementById("formulario");
    // Ocultamos el formulario
    formualrio.style.display = 'none';

    // Mostramos el botón que muestra el formulario
    var btn_mostrar_form = document.getElementById("create_sede");
    btn_mostrar_form.style.display = 'inline';
}

// Función para mostar el formulario para 
function mostrarFormUpdate (){
    // Cogemos el formulario
    var formualrio = document.getElementById("formulario");
    // Mostramos el formulario
    formualrio.style.display = 'inline';

    // Ocultamos el boton de crear empresa:
    var boton_crear = document.getElementById("create_sede");
    boton_crear.style.display = 'none';

    // Ponemos el texto del botón con el valor Actualizar
    if (document.getElementById("crear_sede")){
        var boton = document.getElementById("crear_sede");
        boton.innerHTML = "Actualizar";
    }
    
}

// Funcion para coger todas las empresas y mostrarlas en el formulario
function datosEmpresa (datos) {
    var etiqueta_select = document.getElementById("empresas");
    etiqueta_select.innerHTML = "";

    datos.forEach((empresa) => {
        var valor = document.createElement("option");
        valor.value = empresa.id;
        valor.textContent = empresa.name;
        valor.dataset.company_id = empresa.id;
        valor.dataset.company_name = empresa.name;
        etiqueta_select.appendChild(valor)
    });
}

function volcarDatosUpdate (e){
    // Llamamos a la función para mostrar el formulario
    mostrarFormUpdate();

    // Cogemos los datos de la casa y lo pintamos en los campos correspondientes
    e.preventDefault();

    console.log("e: "+this.dataset.company_name);
    console.log("dataset.id: "+this.dataset.id);
    //console.log("llega");

    
    // Rellenamos el name
    var headquarter_name = document.getElementById("headquarter_name");
    // Le damos el valor del estudiante que le hemos hecho click
    headquarter_name.value = this.dataset.headquarter_name;

    // Rellenamos la empresa
    var company_name = document.getElementById("empresas");
    // Le damos el valor del estudiante que le hemos hecho click
    company_name.value = this.dataset.company_id;

    // Cambiamos el id del boton para hacer la actualización ya que en el windows on load lo usamos para crear un estudiante
    if (document.getElementById("crear_sede")){
        boton = document.getElementById("crear_sede");
        boton.setAttribute('id', 'btn_actualizar');
    }

    // Pasamos el id del estudiante a traves de un dataset
    boton.dataset.id = this.dataset.id;

    // Llamamos a la función actualizar cundo haga click en actualizar:
    boton.onclick = actualizarEmpresa;
}

// Función para crear una empresa
function crearSede(e) {

    e.preventDefault();

    // Obtener los valores del formulario
    var headquarter_name = document.getElementById("headquarter_name").value;
    var company_id = document.getElementById("empresas").value;

    console.log("name: "+headquarter_name);
    console.log("id: "+company_id);
    
    // Crear el objeto de la empresa
    var sede = {
        headquarter_name: headquarter_name,
        company_id: company_id
    };
    
    // Enviar el objeto a través de una petición POST
    fetch('http://127.0.0.1:8000/api/headquarters',{
        method: "POST",
        body: JSON.stringify(sede),
        headers: {
        "Content-Type": "application/json",
        'Authorization': 'Bearer ' + token
        }
    })
        .then(respuesta => respuesta.json())
        .then(datos => {
            console.log("Sede creada: ", datos);

            // Ocultamos el formulario
            ocultaForm();
            
            // Recargamos la página para mostrar la empresa creada
            location.reload();
        })
        .catch(e => console.error("Error al crear la sede: ", e));
}


function actualizarEmpresa(e) {
    e.preventDefault();

    // Obtener los valores del formulario
    var headquarter_name = document.getElementById("headquarter_name").value;
    var company_id = document.getElementById("empresas").value;

    console.log("name: "+headquarter_name);
    console.log("id: "+company_id);
    
    // Crear el objeto de la empresa
    var sede = {
        headquarter_name: headquarter_name,
        company_id: company_id,
        headquarter_id: this.dataset.id
    };
    
    // Enviar el objeto a través de una petición POST
    fetch('http://127.0.0.1:8000/api/headquarters',{
        method: "PUT",
        body: JSON.stringify(sede),
        headers: {
        "Content-Type": "application/json",
        'Authorization': 'Bearer ' + token
        }
    })
        .then(respuesta => respuesta.json())
        .then(datos => {
            console.log("Sede actualizada: ", datos);

            // Ocultamos el formulario
            ocultaForm();
            
            // Recargamos la página para mostrar la empresa creada
            location.reload();
        })
        .catch(e => console.error("Error al crear la sede: ", e));
}

// Funcion para eliminar una empresa
function eliminarSede(event) {
    var sede_id = event.target.dataset.id;
    
    if(confirm("Desea eliminar la sede con id: "+sede_id)){
        // Enviar una petición DELETE para eliminar la sede
        fetch('http://127.0.0.1:8000/api/headquarters/' + sede_id, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            }
        })
            .then(respuesta => {
                alert("Sede eliminada con éxito");  
                console.log("Empresa eliminada");
                location.reload();
            })
            .catch(e => console.error("Error al eliminar la sede: ", e));
        }
}
    
